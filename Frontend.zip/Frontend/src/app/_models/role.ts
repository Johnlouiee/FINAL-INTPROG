export enum Role {
    None = 'None',
    User = 'User',
    Admin = 'Admin'
}